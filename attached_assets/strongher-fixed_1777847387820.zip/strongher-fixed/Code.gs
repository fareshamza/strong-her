// ====================================================
// STRONG HER GYMLOG — Google Apps Script Backend v3
// ====================================================
var CONFIG = {
  SHEET_ID:        '1Ow99c8vPExTsihLWyU2SqvZh6NpskZhvWlVstWHDcdE',
  DRIVE_FOLDER_ID: '1TaBYSOxPdLdeC0Dp3EKx91eTFFRpGPnN',
  ADMIN_PASS:      '0107652871',
}

// ── Setup: run once from Apps Script editor ──────────
function setup() {
  var ss = SpreadsheetApp.openById(CONFIG.SHEET_ID)

  // Orders sheet
  var orders = ss.getSheetByName('Orders') || ss.insertSheet('Orders')
  orders.getRange(1,1,1,13).setValues([[
    'Order ID','Date','Name','Phone','Split','Days',
    'Day Names','Exercises','Screenshot URL','Status',
    'Coupon','Discount','Final Price'
  ]])
  orders.getRange(1,1,1,13).setFontWeight('bold')
    .setBackground('#D4537E').setFontColor('white')
  orders.setFrozenRows(1)

  // Settings sheet
  var cfg = ss.getSheetByName('Settings') || ss.insertSheet('Settings')
  cfg.getRange(1,1,1,2).setValues([['Key','Value']])
  cfg.getRange(2,1,4,2).setValues([
    ['PRICE',     '300'],
    ['VF_NUMBER', '01068093260'],
    ['COUPONS',   'WELCOME10:10,VIP50:50'],
    ['WHATSAPP',  ''],
  ])
  cfg.getRange(1,1,1,2).setFontWeight('bold')
    .setBackground('#D4537E').setFontColor('white')
  ss.toast('Setup done!', 'Strong Her', 3)
}

// ── Helpers ──────────────────────────────────────────
function getSettings() {
  try {
    var ss  = SpreadsheetApp.openById(CONFIG.SHEET_ID)
    var cfg = ss.getSheetByName('Settings')
    if (!cfg) return defaultSettings()
    var rows = cfg.getDataRange().getValues().slice(1)
    var obj  = defaultSettings()
    rows.forEach(function(r) { if (r[0]) obj[r[0]] = String(r[1]) })
    return obj
  } catch(e) {
    return defaultSettings()
  }
}

function defaultSettings() {
  return { PRICE:'300', VF_NUMBER:'01068093260', COUPONS:'WELCOME10:10,VIP50:50', WHATSAPP:'' }
}

function json(obj) {
  return ContentService
    .createTextOutput(JSON.stringify(obj))
    .setMimeType(ContentService.MimeType.JSON)
}

function tryParse(str, fallback) {
  try { return JSON.parse(str) } catch(e) { return fallback }
}

// ── POST ─────────────────────────────────────────────
function doPost(e) {
  try {
    var data = JSON.parse(e.postData.contents)

    // ① Public: جلب الإعدادات العامة للـ frontend
    if (data.action === 'getPublicSettings') {
      var cfg = getSettings()
      return json({ price: cfg.PRICE, vfNumber: cfg.VF_NUMBER, coupons: cfg.COUPONS })
    }

    // ② تسجيل أوردر جديد
    var screenshotUrl = ''
    if (data.screenshot) {
      try {
        var b64   = data.screenshot.split(',')[1] || data.screenshot
        var blob  = Utilities.newBlob(
          Utilities.base64Decode(b64), 'image/jpeg',
          'receipt_' + Date.now() + '.jpg'
        )
        var folder = DriveApp.getFolderById(CONFIG.DRIVE_FOLDER_ID)
        var file   = folder.createFile(blob)
        file.setSharing(DriveApp.Access.ANYONE_WITH_LINK, DriveApp.Permission.VIEW)
        screenshotUrl = file.getUrl()
      } catch(imgErr) {
        screenshotUrl = 'upload_error: ' + imgErr.message
      }
    }

    var sheet   = SpreadsheetApp.openById(CONFIG.SHEET_ID).getSheetByName('Orders')
    var orderId = 'SH' + Date.now()
    var cfg2    = getSettings()
    var finalPrice = data.finalPrice || parseInt(cfg2.PRICE) || 300

    sheet.appendRow([
      orderId,
      Utilities.formatDate(new Date(), 'Africa/Cairo', 'yyyy-MM-dd HH:mm:ss'),
      data.name     || '',
      data.phone    || '',
      data.split    || '',
      data.numDays  || 0,
      JSON.stringify(data.dayNames  || []),
      JSON.stringify(data.exercises || {}),
      screenshotUrl,
      'pending',
      data.couponCode || '',
      data.discount   || 0,
      finalPrice
    ])

    return json({ success: true, orderId: orderId })

  } catch(err) {
    return json({ success: false, error: err.toString() })
  }
}

// ── GET ──────────────────────────────────────────────
function doGet(e) {
  var p = e.parameter || {}

  // ═══ PUBLIC endpoints (بدون باسورد) ═══

  // جلب الإعدادات للـ frontend
  if (p.action === 'publicSettings') {
    var cfg = getSettings()
    return json({ price: cfg.PRICE, vfNumber: cfg.VF_NUMBER, coupons: cfg.COUPONS })
  }

  // تتبع الأوردر (عام — بدون باسورد)
  if (p.action === 'trackOrder') {
    var q = (p.q || '').toLowerCase().trim()
    if (!q) return json([])
    try {
      var sh   = SpreadsheetApp.openById(CONFIG.SHEET_ID).getSheetByName('Orders')
      var rows = sh.getDataRange().getValues().slice(1)
      var res  = rows.filter(function(row) {
        return String(row[0]).toLowerCase().indexOf(q) >= 0 ||
               String(row[3]).toLowerCase().indexOf(q) >= 0
      }).map(function(row) {
        var phone = String(row[3])
        // إخفاء جزء من الرقم للخصوصية
        var safePhone = phone.length > 4
          ? phone.slice(0, 3) + '****' + phone.slice(-3)
          : phone
        return {
          id:         row[0],
          date:       row[1],
          name:       row[2],
          phone:      safePhone,
          split:      row[4],
          numDays:    row[5],
          dayNames:   tryParse(row[6], []),
          exercises:  tryParse(row[7], {}),
          status:     row[9],
          coupon:     row[10],
          discount:   row[11],
          finalPrice: row[12]
        }
      })
      return json(res)
    } catch(e) {
      return json({ error: e.message })
    }
  }

  // ═══ ADMIN endpoints (باسورد مطلوب) ═══

  if (p.pass !== CONFIG.ADMIN_PASS) {
    return json({ error: 'Unauthorized' })
  }

  var sheet = SpreadsheetApp.openById(CONFIG.SHEET_ID).getSheetByName('Orders')

  // جلب كل الأوردرات
  if (p.action === 'getOrders') {
    var rows = sheet.getDataRange().getValues().slice(1)
    var orders = rows.map(function(row, i) {
      return {
        rowIndex:   i + 2,
        id:         row[0],
        date:       row[1],
        name:       row[2],
        phone:      row[3],
        split:      row[4],
        numDays:    row[5],
        dayNames:   tryParse(row[6], []),
        exercises:  tryParse(row[7], {}),
        screenshot: row[8],
        status:     row[9],
        coupon:     row[10],
        discount:   row[11],
        finalPrice: row[12]
      }
    })
    return json(orders)
  }

  // تحديث حالة الأوردر
  if (p.action === 'updateStatus') {
    sheet.getRange(parseInt(p.row), 10).setValue(p.status)
    return json({ success: true })
  }

  // جلب الإعدادات (للأدمن)
  if (p.action === 'getSettings') {
    return json(getSettings())
  }

  // حفظ الإعدادات
  if (p.action === 'saveSettings') {
    try {
      var ss   = SpreadsheetApp.openById(CONFIG.SHEET_ID)
      var cfg  = ss.getSheetByName('Settings')

      // لو مفيش شيت Settings، اعمله
      if (!cfg) {
        cfg = ss.insertSheet('Settings')
        cfg.getRange(1,1,1,2).setValues([['Key','Value']])
        cfg.getRange(2,1,4,2).setValues([
          ['PRICE','300'],['VF_NUMBER','01068093260'],
          ['COUPONS',''],['WHATSAPP','']
        ])
      }

      var updates = tryParse(p.data || '{}', {})
      var rows    = cfg.getDataRange().getValues()

      // update existing keys
      var updated = {}
      for (var i = 1; i < rows.length; i++) {
        var key = rows[i][0]
        if (key && updates[key] !== undefined) {
          cfg.getRange(i + 1, 2).setValue(updates[key])
          updated[key] = true
        }
      }

      // add new keys لو مش موجودة
      Object.keys(updates).forEach(function(key) {
        if (!updated[key]) {
          cfg.appendRow([key, updates[key]])
        }
      })

      return json({ success: true })
    } catch(saveErr) {
      return json({ success: false, error: saveErr.toString() })
    }
  }

  return json({ error: 'Unknown action: ' + p.action })
}
